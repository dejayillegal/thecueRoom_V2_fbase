# thecueRoom – Supabase + GitHub Pages Patch

This archive provides a PR-ready set of files to migrate platform/ENV from Firebase to Supabase
and deploy the **unchanged UI** to GitHub Pages via SSG export.

- See `MIGRATION.md` for step-by-step.
- Use `CODEx_PROMPT.md` to drive an agent to do code-wide replacements safely.
